# Hexdump
Fun feature: By editing the Macro HEX_DUMP_LEN you can set the count of displayed Hex values in one line.
I dare u to try it @.@
